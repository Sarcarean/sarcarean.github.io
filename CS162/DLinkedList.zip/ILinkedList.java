public interface ILinkedList<E>
{ 
    public void add(int index, E e);
    public void addFirst(E e);
    public void addLast(E e);   
    public void delete(int index);    
    public void deleteFirst();
    public void deleteLast();
    public int size();
    public void clear();
    public boolean contains(E e);
    public E get(int index);
    public E getFirst();
    public E getLast();  
}
    
    
    
   